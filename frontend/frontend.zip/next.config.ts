import type { NextConfig } from "next";

const nextConfig: NextConfig = {
  typescript: {
    ignoreBuildErrors: true,
  },

  images: {
    remotePatterns: [
      { protocol: "https", hostname: "picsum.photos" },
      { protocol: "http", hostname: "localhost" },
      { protocol: "https", hostname: "res.cloudinary.com" },
      { protocol: "https", hostname: "live.themewild.com" },
      {
        protocol: "https",
        hostname: "oncohealthmart-data-001.s3.ap-south-1.amazonaws.com",
      },
    ],
  },
};

export default nextConfig;