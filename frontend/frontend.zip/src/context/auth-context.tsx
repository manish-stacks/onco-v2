"use client";

import {
  createContext,
  useCallback,
  useContext,
  useEffect,
  useState,
  type ReactNode,
} from "react";
import { authApi, onUnauthorized, tokenStore, ApiError } from "@/lib/api";
import type { Customer } from "@/types";

interface AuthContextValue {
  user: Customer | null;
  loading: boolean;
  isLoggedIn: boolean;
  requestOtp: (mobile: string, customer_name?: string) => Promise<{ customer_id: string | number; is_new_user?: boolean; dev_otp?: string }>;
  verifyOtp: (customer_id: string | number, otp: string) => Promise<Customer | null>;
  loginPassword: (mobile: string, password: string) => Promise<Customer | null>;
  register: (payload: { mobile: string; password: string; customer_name?: string }) => Promise<Customer | null>;
  logout: () => void;
  refresh: () => Promise<void>;
}

const AuthContext = createContext<AuthContextValue | null>(null);

export function AuthProvider({ children }: { children: ReactNode }) {
  const [user, setUser] = useState<Customer | null>(null);
  const [loading, setLoading] = useState(true);

  const refresh = useCallback(async () => {
    if (!tokenStore.has()) {
      setUser(null);
      setLoading(false);
      return;
    }
    try {
      const me = await authApi.me<Customer>();
      setUser(me);
    } catch {
      tokenStore.clear();
      setUser(null);
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => {
    refresh();
  }, [refresh]);

  useEffect(() => onUnauthorized(() => setUser(null)), []);

  const requestOtp = useCallback(async (mobile: string, customer_name?: string) => {
    const data = await authApi.requestOtp({ mobile, customer_name, allow_signup: true });
    return (data || {}) as { customer_id: string | number; is_new_user?: boolean; dev_otp?: string };
  }, []);

  const verifyOtp = useCallback(async (customer_id: string | number, otp: string) => {
    const data = await authApi.verifyOtp({ customer_id, otp });
    await refresh();
    return (data?.customer as Customer) ?? null;
  }, [refresh]);

  const loginPassword = useCallback(async (mobile: string, password: string) => {
    const data = await authApi.login({ mobile, password });
    await refresh();
    return (data?.customer as Customer) ?? null;
  }, [refresh]);

  const register = useCallback(async (payload: { mobile: string; password: string; customer_name?: string }) => {
    const data = await authApi.register(payload);
    await refresh();
    return (data?.customer as Customer) ?? null;
  }, [refresh]);

  const logout = useCallback(() => {
    authApi.logout();
    setUser(null);
  }, []);

  return (
    <AuthContext.Provider
      value={{
        user,
        loading,
        isLoggedIn: !!user,
        requestOtp,
        verifyOtp,
        loginPassword,
        register,
        logout,
        refresh,
      }}
    >
      {children}
    </AuthContext.Provider>
  );
}

export function useAuth() {
  const ctx = useContext(AuthContext);
  if (!ctx) throw new Error("useAuth must be used within AuthProvider");
  return ctx;
}

export { ApiError };
