"use client";

import { useEffect, useState } from "react";
import Image from "next/image";
import Link from "next/link";
import { motion, AnimatePresence } from "framer-motion";
import { Minus, Plus, Trash2, ShoppingBag, FileWarning, Tag, ArrowRight, AlertTriangle, Info, X } from "lucide-react";
import { Button } from "@/components/ui/button";
import { CouponSidebar, type CouponOption } from "@/components/CouponSidebar";
import { mediaUrl, cartApi, ApiError } from "@/lib/api";
import { formatINR } from "@/lib/utils";
import { useStore } from "@/hooks/use-store";
import { useAuth } from "@/context/auth-context";
import { clearAppliedCoupon, getAppliedCoupon, saveAppliedCoupon } from "@/lib/coupon";


export default function CartPage() {
  const { isLoggedIn } = useAuth();
  const { cartItems, summary, cartLoading, isGuestCart, updateQuantity, removeFromCart, refreshCart } = useStore();
  const [coupon, setCoupon] = useState("");
  const [couponMsg, setCouponMsg] = useState<string | null>(null);
  const [couponError, setCouponError] = useState(false);
  const [applying, setApplying] = useState(false);
  const [appliedCode, setAppliedCode] = useState<string | null>(null);
  const [discount, setDiscount] = useState(0);
  const [showCouponSidebar, setShowCouponSidebar] = useState(false);
  const [couponList, setCouponList] = useState<CouponOption[]>([]);
  const [couponListLoading, setCouponListLoading] = useState(false);

  // Simple bill breakup: Total MRP -> product-level discount -> coupon -> Cart Total.
  const totalMrp = cartItems.reduce((s, i) => s + (Number(i.product_mrp) || Number(i.product_sp) || 0) * i.product_quantity, 0);
  const mrpDiscount = Math.max(totalMrp - (summary?.subtotal ?? 0), 0);
  const totalSaved = mrpDiscount + discount;

  // Restore a coupon that was applied earlier in this session
  useEffect(() => {
    const saved = getAppliedCoupon();
    if (saved) {
      setAppliedCode(saved.code);
      setDiscount(saved.discount);
      setCoupon(saved.code);
    }
  }, []);

  async function applyCoupon(codeOverride?: string) {
    const code = (codeOverride ?? coupon).trim().toUpperCase();
    if (!code) return;
    if (!isLoggedIn) {
      setCouponError(true);
      setCouponMsg("Verify your mobile number at checkout to apply a coupon");
      return;
    }
    setApplying(true);
    setCouponMsg(null);
    setCouponError(false);
    try {
      // The endpoint validates the code and returns the discount it would give.
      // We store it so the checkout page can send it with the order.
      const res = await cartApi.applyCoupon<{ coupon_code: string; discount: number }>(code);
      const value = Number(res?.discount) || 0;
      saveAppliedCoupon(code, value);
      setAppliedCode(code);
      setCoupon(code);
      setDiscount(value);
      setCouponMsg(`Coupon "${code}" applied — ${formatINR(value)} off`);
      setShowCouponSidebar(false);
      await refreshCart();
    } catch (err) {
      clearAppliedCoupon();
      setAppliedCode(null);
      setDiscount(0);
      setCouponError(true);
      setCouponMsg(err instanceof ApiError ? err.message : "Could not apply coupon");
    } finally {
      setApplying(false);
    }
  }

  function removeCoupon() {
    clearAppliedCoupon();
    setAppliedCode(null);
    setDiscount(0);
    setCoupon("");
    setCouponMsg(null);
    setCouponError(false);
  }

  async function openCouponSidebar() {
    setShowCouponSidebar(true);
    if (couponList.length) return;
    setCouponListLoading(true);
    try {
      const res = await cartApi.availableCoupons<CouponOption[]>();
      setCouponList(res || []);
    } catch {
      setCouponList([]);
    } finally {
      setCouponListLoading(false);
    }
  }

  if (cartLoading && cartItems.length === 0) {
    return <div className="mx-auto max-w-7xl px-4 py-24 text-center text-[var(--ink-soft)]">Loading your cart…</div>;
  }

  if (cartItems.length === 0) {
    return (
      <div className="mx-auto flex max-w-7xl flex-col items-center px-4 py-24 text-center sm:px-6 lg:px-8">
        <span className="mb-6 flex h-20 w-20 items-center justify-center rounded-full bg-[var(--blue-50)] text-[var(--blue-500)]">
          <ShoppingBag size={32} />
        </span>
        <h1 className="mb-2 font-display text-2xl font-bold text-[var(--ink)]">Your cart is empty</h1>
        <p className="mb-6 max-w-sm text-[var(--ink-soft)]">Looks like you haven&apos;t added any medicines yet. Explore our catalogue to get started.</p>
        <Button href="/shop" icon={<ArrowRight size={16} />}>Continue Shopping</Button>
      </div>
    );
  }

  return (
    <div className="mx-auto max-w-7xl px-4 py-10 sm:px-6 lg:px-8">
      <h1 className="mb-8 font-display text-3xl font-bold text-[var(--ink)]">Your Cart</h1>

      <div className="grid grid-cols-1 gap-8 lg:grid-cols-[1fr_360px]">
        <div className="space-y-4">
          {isGuestCart && cartItems.length > 0 && (
            <div className="flex items-start gap-3 rounded-[var(--radius-md)] border border-[var(--blue-50)] bg-[var(--blue-50)]/40 p-4 text-sm text-[var(--blue-600)]">
              <Info size={18} className="mt-0.5 shrink-0" />
              <p>
                This is only an estimated total. The exact shipping charges and coupon discount will be displayed at checkout after mobile verification. Your cart will remain safely saved on your phone.
              </p>
            </div>
          )}
          {/* {summary?.requires_prescription && (
            <div className="flex items-start gap-3 rounded-[var(--radius-md)] border border-[#FCE1B8] bg-[#FFF8EC] p-4 text-sm text-[#8A5A0C]">
              <FileWarning size={18} className="mt-0.5 shrink-0" />
              <p>
                Your cart contains prescription medicines. You&apos;ll need to upload a valid prescription at checkout.{" "}
                <Link href="/prescription-upload" className="font-semibold underline">Upload now</Link>
              </p>
            </div>
          )} */}
          {summary?.has_out_of_stock && (
            <div className="flex items-start gap-3 rounded-[var(--radius-md)] border border-[#FCC7BE] bg-[#FFF1EE] p-4 text-sm text-[var(--coral-500)]">
              <AlertTriangle size={18} className="mt-0.5 shrink-0" />
              <p>Some items in your cart don&apos;t have enough stock: {summary.out_of_stock_items?.join(", ")}. Please update quantities before checkout.</p>
            </div>
          )}
          <AnimatePresence>
            {cartItems.map((item) => (
              <motion.div
                key={item.cart_id}
                layout
                initial={{ opacity: 0 }}
                animate={{ opacity: 1 }}
                exit={{ opacity: 0, x: -20 }}
                className="flex gap-4 rounded-[var(--radius-md)] border border-[var(--line)] bg-white p-4"
              >
                <Link href={`/medicines/${item.slug}`} className="relative h-24 w-24 shrink-0 overflow-hidden rounded-[var(--radius-sm)] bg-[var(--blue-50)]">
                  <Image src={mediaUrl(item.image_1)} alt={item.product_name} fill className="object-cover" />
                </Link>
                <div className="flex-1">
                  <Link href={`/medicines/${item.slug}`} className="font-semibold text-[var(--ink)] hover:underline">
                    {item.product_name}
                  </Link>
                  {!item.in_stock && (
                    <p className="mt-1 text-xs font-medium text-[var(--coral-500)]">
                      Only {item.available_quantity ?? 0} available
                    </p>
                  )}
                  <div className="mt-3 flex items-center rounded-full border border-[var(--line)] w-fit">
                    <button onClick={() => updateQuantity(item.cart_id, item.product_quantity - 1)} className="flex h-8 w-8 items-center justify-center">
                      <Minus size={13} />
                    </button>
                    <span className="w-7 text-center text-sm font-semibold font-mono-nums">{item.product_quantity}</span>
                    <button onClick={() => updateQuantity(item.cart_id, item.product_quantity + 1)} className="flex h-8 w-8 items-center justify-center">
                      <Plus size={13} />
                    </button>
                  </div>
                </div>
                <div className="flex shrink-0 flex-col items-end justify-between">
                  <button onClick={() => removeFromCart(item.cart_id)} className="text-[var(--ink-soft)] hover:text-[var(--coral-500)]">
                    <Trash2 size={17} />
                  </button>
                  <p className="font-mono-nums font-bold text-[var(--ink)]">{formatINR(item.line_total)}</p>
                </div>
              </motion.div>
            ))}
          </AnimatePresence>
        </div>

        <div className="h-fit rounded-[var(--radius-md)] border border-[var(--line)] bg-white p-6">
          <h2 className="mb-4 font-semibold text-[var(--ink)]">Order Summary</h2>

          <div className="mb-4">
            {appliedCode ? (
              <div className="flex h-11 items-center justify-between gap-2 rounded-full border border-[var(--mint-600)] bg-[var(--mint-600)]/5 px-4">
                <span className="flex items-center gap-2 text-sm font-semibold text-[var(--mint-600)]">
                  <Tag size={15} /> {appliedCode} applied
                </span>
                <button onClick={removeCoupon} className="flex items-center gap-1 text-sm font-semibold text-[var(--ink-soft)] hover:text-[var(--coral-500)]">
                  <X size={14} /> Remove
                </button>
              </div>
            ) : (
              <button
                type="button"
                onClick={openCouponSidebar}
                className="flex h-11 w-full items-center justify-between gap-2 rounded-full border border-[var(--line)] px-4 text-left text-sm"
              >
                <span className="flex items-center gap-2 text-[var(--ink-soft)]"><Tag size={15} /> Apply coupon</span>
                <span className="text-xs font-semibold text-[var(--blue-600)]">View all coupons</span>
              </button>
            )}
          </div>
          {couponMsg && (
            <p className={`mb-4 text-xs font-medium ${couponError ? "text-[var(--coral-500)]" : "text-[var(--mint-600)]"}`}>
              {couponMsg}
            </p>
          )}

          <div className="space-y-2 border-t border-[var(--line)] pt-4 text-sm font-mono-nums">
            <div className="flex justify-between text-[var(--ink-soft)]">
              <span>Total MRP</span>
              <span>{formatINR(totalMrp)}</span>
            </div>
            {mrpDiscount > 0 && (
              <div className="flex justify-between text-[var(--mint-600)]">
                <span>Discount on MRP</span>
                <span>- {formatINR(mrpDiscount)}</span>
              </div>
            )}
            {discount > 0 && (
              <div className="flex justify-between text-[var(--mint-600)]">
                <span>Coupon ({appliedCode})</span>
                <span>- {formatINR(discount)}</span>
              </div>
            )}
            <div className="flex justify-between border-t border-[var(--line)] pt-2 text-base font-bold text-[var(--ink)]">
              <span>Cart Total</span>
              <span>{formatINR(Math.max((summary?.total ?? 0) - discount, 0))}</span>
            </div>
            {totalSaved > 0 && (
              <p className="rounded-full bg-[var(--mint-600)]/10 px-3 py-1.5 text-center text-xs font-semibold text-[var(--mint-600)]">
                You saved {formatINR(totalSaved)}
              </p>
            )}
            <p className="pt-1 text-xs text-[var(--ink-soft)]">Final shipping &amp; COD fee shown at checkout.</p>
          </div>

          <Button href="/checkout" size="lg" className="mt-6 w-full" icon={<ArrowRight size={16} />}>
            Proceed to Checkout
          </Button>
          <Button href="/shop" variant="outline" size="md" className="mt-3 w-full">
            Add More Medicine
          </Button>
        </div>
      </div>

      <CouponSidebar
        open={showCouponSidebar}
        onClose={() => setShowCouponSidebar(false)}
        couponInput={coupon}
        setCouponInput={setCoupon}
        onApply={applyCoupon}
        applying={applying}
        appliedCode={appliedCode}
        onRemove={removeCoupon}
        message={couponMsg}
        messageError={couponError}
        coupons={couponList}
        couponsLoading={couponListLoading}
      />
    </div>
  );
}
