import { defineConfig } from 'vite';
import react from '@vitejs/plugin-react';
import path from 'path';

export default defineConfig({
  plugins: [react()],
  resolve: {
    alias: { '@': path.resolve(__dirname, './src') },
  },
  build: {
    // recharts bhaari hai — usko alag chunk me rakho taaki pehla load halka rahe
    rollupOptions: {
      output: {
        manualChunks: {
          react: ['react', 'react-dom', 'react-router-dom'],
          charts: ['recharts'],
        },
      },
    },
  },
  server: {
    port: 5174,
    proxy: {
      // dev me CORS ka jhanjhat na ho — /api seedha backend pe chala jaata hai
      '/api': {
        target: process.env.VITE_API_PROXY || 'https://www.betaapi.oncohealthmart.com',
        changeOrigin: true,
      },
    },
  },
});
