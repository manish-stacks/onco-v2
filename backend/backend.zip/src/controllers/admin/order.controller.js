const orderModel = require('../../models/order.model');
const prescriptionModel = require('../../models/prescription.model');
const orderService = require('../../services/order.service');
const adminModel = require('../../models/admin.model');
const customerModel = require('../../models/customer.model');
const notify = require('../../services/notification.service');
const dtdc = require('../../services/dtdc.service');
const cache = require('../../utils/cache');
const { ok, fail, paginated, asyncHandler } = require('../../utils/response');
const { getPagination, getSort, toCsv } = require('../../utils/helpers');
const { ORDER_STATUSES, ORDER_STATUS_FLOW, PAYMENT_STATUS } = require('../../config/constants');
const { orderRef: orderRefUtil } = require('../../utils/helpers');

/**
 * One set of endpoints for both web and app orders.
 *   ?orderFrom=web  -> only website orders
 *   ?orderFrom=app  -> only mobile app orders
 *   (no filter) -> both combined
 */

/** GET /admin/orders */
const list = asyncHandler(async (req, res) => {
  const { page, limit, offset } = getPagination(req.query, 25, 100);
  const sort = getSort(req.query, orderModel.SORTABLE, 'order_date');

  const { rows, total } = await orderModel.list({
    status: req.query.status,
    statuses: req.query.statuses,
    payment_status: req.query.payment_status,
    payment_mode: req.query.payment_mode,
    orderFrom: req.query.orderFrom,
    city: req.query.city,
    state: req.query.state,
    from_date: req.query.from_date,
    to_date: req.query.to_date,
    min_amount: req.query.min_amount,
    max_amount: req.query.max_amount,
    search: req.query.search,
    customer_id: req.query.customer_id,
  }, { limit, offset }, sort);

  return paginated(res, rows, total, page, limit);
});

/** GET /admin/orders/stats — for the summary cards, cached for 60s */
const stats = asyncHandler(async (req, res) => {
  const filters = {
    orderFrom: req.query.orderFrom,
    from_date: req.query.from_date,
    to_date: req.query.to_date,
  };
  const key = cache.buildKey('admin:orders:stats', filters);
  return ok(res, await cache.getOrSet(key, cache.TTL.SHORT, () => orderModel.stats(filters)));
});

/** GET /admin/orders/:orderId */
const detail = asyncHandler(async (req, res) => {
  const order = await orderModel.findById(req.params.orderId);
  if (!order) return fail(res, 'Order not found', 404);

  // which status is allowed next — the frontend dropdown is built from this
  order.allowed_next_statuses = ORDER_STATUS_FLOW[order.status] || [];
  return ok(res, order);
});

/** PATCH /admin/orders/:orderId/status */
const updateStatus = asyncHandler(async (req, res) => {
  const { status, note, force } = req.body;

  if (!ORDER_STATUSES.includes(status)) {
    return fail(res, `status must be one of: ${ORDER_STATUSES.join(', ')}`, 422);
  }

  const order = await orderModel.findById(req.params.orderId, { withItems: false, withHistory: false });
  if (!order) return fail(res, 'Order not found', 404);

  // validate the flow — can be overridden with force=true (for super admins)
  const allowed = ORDER_STATUS_FLOW[order.status] || [];
  if (!force && !allowed.includes(status)) {
    return fail(
      res,
      `Cannot move directly from '${order.status}' to '${status}'. Allowed: ${allowed.join(', ') || 'none'}`,
      409
    );
  }

  const result = await orderService.changeStatus(req.params.orderId, status, {
    changedBy: req.admin.admin_username,
    note,
  });

  await adminModel.logActivity({
    admin_id: req.admin.admin_id, admin_username: req.admin.admin_username,
    action: 'status_change', module: 'orders', record_id: req.params.orderId,
    description: `${order.status} -> ${status}`, ip_address: req.ip,
  });

  return ok(res, result, 'Order status updated');
});

/** POST /admin/orders/:orderId/cancel — with refund + stock restore */
const cancelOrder = asyncHandler(async (req, res) => {
  const result = await orderService.cancelOrder(req.params.orderId, {
    changedBy: req.admin.admin_username,
    reason: req.body.reason,
    refundPayment: req.body.refund !== false,
  });

  await adminModel.logActivity({
    admin_id: req.admin.admin_id, admin_username: req.admin.admin_username,
    action: 'cancel', module: 'orders', record_id: req.params.orderId,
    description: req.body.reason, ip_address: req.ip,
  });

  return ok(res, result, result.refund?.failed
    ? 'The order was cancelled, but the refund failed — check it manually'
    : 'Order cancelled');
});

/** DELETE /admin/orders/:orderId — hard delete, only while still Pending */
const deleteOrder = asyncHandler(async (req, res) => {
  await orderService.deletePendingOrder(req.params.orderId, {
    changedBy: req.admin.admin_username,
  });

  await adminModel.logActivity({
    admin_id: req.admin.admin_id, admin_username: req.admin.admin_username,
    action: 'delete', module: 'orders', record_id: req.params.orderId,
    description: 'Deleted a pending order', ip_address: req.ip,
  });

  return ok(res, { deleted: true }, 'Order deleted');
});

/** PATCH /admin/orders/:orderId/tracking */
const updateTracking = asyncHandler(async (req, res) => {
  const order = await orderModel.findById(req.params.orderId, { withItems: false, withHistory: false });
  if (!order) return fail(res, 'Order not found', 404);

  await orderModel.updateTracking(req.params.orderId, {
    awb_number: req.body.awb_number,
    courier_name: req.body.courier_name,
    tracking_status: req.body.tracking_status,
    tracking_location: req.body.tracking_location,
    tracking_datetime: req.body.tracking_datetime,
    tracking_details: req.body.tracking_details,
  });

  await cache.invalidate.orders();
  return ok(res, null, 'Tracking details updated');
});

/** PATCH /admin/orders/:orderId/payment — manual payment mark (bank transfer, etc.) */
const updatePayment = asyncHandler(async (req, res) => {
  const { payment_status, payment_mode, transaction_number } = req.body;
  const valid = Object.values(PAYMENT_STATUS);
  if (!valid.includes(payment_status)) {
    return fail(res, `payment_status must be one of: ${valid.join(', ')}`, 422);
  }
  if (payment_mode && !['cod', 'online'].includes(payment_mode)) {
    return fail(res, "payment_mode must be 'cod' or 'online'", 422);
  }

  await orderModel.updatePayment(req.params.orderId, { payment_status, payment_mode, transaction_number });
  await cache.invalidate.orders();

  await adminModel.logActivity({
    admin_id: req.admin.admin_id, admin_username: req.admin.admin_username,
    action: 'payment_update', module: 'orders', record_id: req.params.orderId,
    description: `${payment_status}${payment_mode ? ` (${payment_mode})` : ''}`, ip_address: req.ip,
  });

  return ok(res, null, 'Payment updated');
});

/** PATCH /admin/orders/:orderId — shipping address / notes edit */
const updateOrder = asyncHandler(async (req, res) => {
  const updated = await orderModel.updateFields(req.params.orderId, req.body);
  if (!updated) return fail(res, 'No valid field was provided to update', 422);

  await cache.invalidate.orders();
  return ok(res, await orderModel.findById(req.params.orderId), 'Order updated');
});

/** GET /admin/orders/export — CSV (one row per item) */
const exportCsv = asyncHandler(async (req, res) => {
  const rows = await orderModel.listForExport({
    status: req.query.status,
    payment_status: req.query.payment_status,
    payment_mode: req.query.payment_mode,
    orderFrom: req.query.orderFrom,
    from_date: req.query.from_date,
    to_date: req.query.to_date,
    search: req.query.search,
  });

  const csv = toCsv(rows, [
    'order_id', 'databaseOrderID', 'order_date', 'customer_name', 'customer_phone',
    'customer_city', 'customer_state', 'customer_pincode', 'status', 'payment_status',
    'payment_mode', 'orderFrom', 'product_name', 'sku', 'unit_price', 'unit_quantity',
    'line_total', 'subtotal', 'order_gst', 'coupon_code', 'coupon_discount',
    'shipping_charge', 'amount', 'awb_number', 'courier_name',
  ]);

  await adminModel.logActivity({
    admin_id: req.admin.admin_id, admin_username: req.admin.admin_username,
    action: 'export', module: 'orders', description: `${rows.length} rows`, ip_address: req.ip,
  });

  res.setHeader('Content-Type', 'text/csv; charset=utf-8');
  res.setHeader('Content-Disposition', `attachment; filename="orders-${Date.now()}.csv"`);
  return res.send(csv);
});

/** GET /admin/orders/:orderId/invoice — invoice ka structured data (PDF frontend banaye) */
const invoice = asyncHandler(async (req, res) => {
  const order = await orderModel.findById(req.params.orderId);
  if (!order) return fail(res, 'Order not found', 404);

  const settingsModel = require('../../models/settings.model');
  const settings = await settingsModel.get();

  return ok(res, {
    invoice_number: order.invoice_number || `INV/${order.order_id}`,
    invoice_date: order.order_date,
    original_invoice_url: order.original_invoice_url || null,
    seller: settings ? {
      name: settings.organization,
      address: settings.contact_address,
      phone: settings.contact_phone,
      email: settings.contact_email,
      logo: settings.logo,
    } : null,
    buyer: {
      name: order.customer_name,
      phone: order.customer_phone,
      email: order.customer_email,
      billing_address: order.customer_address,
      shipping_address: order.customer_shipping_address,
      city: order.customer_city,
      state: order.customer_state,
      pincode: order.customer_pincode,
    },
    items: order.items,
    totals: {
      subtotal: order.subtotal,
      gst: order.order_gst,
      discount: order.coupon_discount,
      shipping: order.shipping_charge,
      additional: order.additional_charge,
      total: order.amount,
    },
    payment: {
      mode: order.payment_mode,
      status: order.payment_status,
      transaction: order.transaction_number,
    },
  });
});

/**
 * POST /admin/orders/:orderId/original-invoice
 * Admin uploads the real invoice PDF (usually right after DTDC booking).
 * Once this exists, it replaces the auto-generated (temp) invoice everywhere —
 * customer app, admin panel, and any future emails/prints. Before this is
 * uploaded, the auto-generated invoice keeps working exactly as before.
 */
const uploadOriginalInvoice = asyncHandler(async (req, res) => {
  if (!req.file) return fail(res, 'Invoice file is required', 422);

  const order = await orderModel.findById(req.params.orderId);
  if (!order) return fail(res, 'Order not found', 404);

  const { storeFile } = require('../../middleware/upload');
  const url = await storeFile(req.file, 'invoices');
  await orderModel.setOriginalInvoice(req.params.orderId, url);

  await adminModel.logActivity({
    admin_id: req.admin.admin_id, admin_username: req.admin.admin_username,
    action: 'invoice_upload', module: 'orders', record_id: req.params.orderId,
    description: 'Original invoice uploaded', ip_address: req.ip,
  });

  return ok(res, { original_invoice_url: url }, 'Original invoice uploaded');
});

/**
 * PATCH /admin/orders/:orderId/prescription
 * Approve / reject the prescription straight from the order detail page,
 * so there is no need to jump to the separate Prescriptions page.
 * body: { status: 'Approved' | 'Rejected' | ..., rejection_reason, notes }
 */
const updatePrescriptionStatus = asyncHandler(async (req, res) => {
  const { status, rejection_reason, notes } = req.body;

  const order = await orderModel.findById(req.params.orderId, { withItems: false, withHistory: false });
  if (!order) return fail(res, 'Order not found', 404);
  if (!order.prescription_id) return fail(res, 'No prescription is attached to this order', 409);

  const { PRESCRIPTION_STATUSES } = require('../../config/constants');
  if (!PRESCRIPTION_STATUSES.includes(status)) {
    return fail(res, `status must be one of: ${PRESCRIPTION_STATUSES.join(', ')}`, 422);
  }
  if (status === 'Rejected' && !rejection_reason) {
    return fail(res, 'A reason is required in order to reject', 422);
  }

  await prescriptionModel.updateStatus(order.prescription_id, status, {
    reviewedBy: req.admin.admin_id,
    rejectionReason: rejection_reason,
    notes,
  });

  await adminModel.logActivity({
    admin_id: req.admin.admin_id, admin_username: req.admin.admin_username,
    action: 'status_change', module: 'prescriptions', record_id: order.prescription_id,
    description: `Order ${orderRefUtil(order)} — prescription -> ${status}`, ip_address: req.ip,
  });

  await cache.invalidate.orders();

  // Same customer notification as the Prescriptions page (SMS + push)
  try {
    const fresh = await prescriptionModel.findById(order.prescription_id);
    const customer = fresh?.customer_id ? await customerModel.findById(fresh.customer_id) : null;
    notify.prescriptionReviewed(
      { ...fresh, order_id: order.order_id, order_date: order.order_date, databaseOrderID: order.databaseOrderID },
      customer
    );
  } catch (e) {
    console.error('[order] prescription notify fail:', e.message);
  }

  return ok(res, await orderModel.findById(req.params.orderId), 'Prescription status updated');
});

/**
 * POST /admin/track-shipment — any-AWB live lookup for admin/staff, no order
 * needed. Same underlying call as the public customer-facing one
 * (app/order.controller.js trackShipmentPublic) — kept separate so it's
 * gated behind admin auth like everything else on this side.
 */
const trackShipment = asyncHandler(async (req, res) => {
  const awb = String(req.body?.awb || '').trim();
  if (!awb) return fail(res, 'AWB number is required', 422);
  if (!dtdc.isConfigured()) return fail(res, 'DTDC is not configured', 503);

  try {
    const result = await dtdc.trackShipment(awb);
    const steps = (result.scans || [])
      .slice()
      .sort((a, b) => new Date(a.scan_at || 0) - new Date(b.scan_at || 0))
      .map((s) => ({ status: s.description, detail: s.detail, location: s.origin || s.destination || null, at: s.scan_at }));
    const latestStep = steps[steps.length - 1];
    const currentStatus = result.header?.strStatus || latestStep?.status || 'Pickup scheduled';

    const order = await orderModel.findByRef(awb).catch(() => null);

    return ok(res, {
      awb,
      ref_no: order ? order.databaseOrderID : (result.header?.strRefNo || null),
      order_id: order ? order.order_id : null,
      current_status: currentStatus,
      stage: dtdc.stageFromStatus(currentStatus) || (steps.length ? 'picked_up' : null),
      origin: result.header?.strOrigin || result.header?.strOriginCity || null,
      destination: result.header?.strDestination || result.header?.strDestinationCity
        || (order ? [order.customer_shipping_city || order.customer_city, order.customer_shipping_pincode].filter(Boolean).join(', ') : null),
      expected_delivery: result.header?.strExpectedDeliveryDate || result.header?.strEDD || null,
      steps,
    });
  } catch (err) {
    return fail(res, err.response?.data?.error || 'Could not fetch tracking — check the AWB number', 502);
  }
});

module.exports = {
  list, stats, detail, updateStatus, cancelOrder, deleteOrder, updateTracking,
  updatePayment, updateOrder, exportCsv, invoice, uploadOriginalInvoice, updatePrescriptionStatus,
  trackShipment,
};
